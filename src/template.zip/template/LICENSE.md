<!-- Check https://choosealicense.com/ for some open source licenses. -->
